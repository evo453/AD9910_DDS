#include "32_configuration.h"
#include "oledfont.h"
#include "OLED_High_inch.h"

//OLED的显存
//存放格式如下.
//[0]0 1 2 3 ... 127	
//[1]0 1 2 3 ... 127	
//[2]0 1 2 3 ... 127	
//[3]0 1 2 3 ... 127	
//[4]0 1 2 3 ... 127	
//[5]0 1 2 3 ... 127	
//[6]0 1 2 3 ... 127	
//[7]0 1 2 3 ... 127 			   
//=================================


//=====引脚配置=====//
#define OLED_W_SCL(x)		GPIO_WriteBit(GPIOB, GPIO_Pin_8, (BitAction)(x))
#define OLED_W_SDA(x)		GPIO_WriteBit(GPIOB, GPIO_Pin_9, (BitAction)(x))


//===========引脚初始化============//
void OLED_I2C_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;   
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
	

 	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;		//推挽输出				
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;
 	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	
	OLED_W_SCL(1);
	OLED_W_SDA(1);
}
//===============================//



/**
  * @brief  IIC开始
  * @param  无
  * @retval 无
  */
void IIC_Start(void)
{	
    OLED_W_SCL(1);
	OLED_W_SDA(1);
	OLED_W_SDA(0);
	OLED_W_SCL(0);
}


/**
  * @brief  IIC停止
  * @param  无
  * @retval 无
  */
void IIC_Stop(void)
{   
    OLED_W_SCL(1);
	OLED_W_SDA(0);
	OLED_W_SDA(1);
}


/**
  * @brief  IIC等待响应
  * @param  无
  * @retval 无
  */
void IIC_Wait_Ack()
{
	OLED_W_SCL(1);
	OLED_W_SCL(0);
}


/**
  * @brief  IIC发送一个字节
  * @param  IIC_Byte 要发送的一个字节
  * @retval 无
  */
void Write_IIC_Byte(uint8_t IIC_Byte)
{
	uint8_t i;
	uint8_t m, da;

	da = IIC_Byte;
	OLED_W_SCL(0);

	for(i = 0; i < 8; i++)		
	{
		m = da;
		//OLED_W_SCL(0);
		m = m & 0x80;
		if(m == 0x80) 
            OLED_W_SDA(1);
		else 
            OLED_W_SDA(0);
			da = da<<1;

		IIC_Wait_Ack();         //额外的一个时钟，不处理应答信号
	}
}


/**
  * @brief  IIC写命令
  * @param  IIC_Command 要写入的命令
  * @retval 无
  */
void Write_IIC_Command(uint8_t IIC_Command)
{
   IIC_Start();
   Write_IIC_Byte(0x78);            //从机地址, SA0=0
	IIC_Wait_Ack();	
   Write_IIC_Byte(0x00);			//写命令
	IIC_Wait_Ack();	
   Write_IIC_Byte(IIC_Command); 
	IIC_Wait_Ack();	
   IIC_Stop();
}


/**
  * @brief  IIC写数据
  * @param  IIC_Data 要写入的数据
  * @retval 无
  */
void Write_IIC_Data(uint8_t IIC_Data)
{
   IIC_Start();
   Write_IIC_Byte(0x78);			//从机地址 D/C#=0; R/W#=0
	IIC_Wait_Ack();	
   Write_IIC_Byte(0x40);			//写数据
	IIC_Wait_Ack();	
   Write_IIC_Byte(IIC_Data);
	IIC_Wait_Ack();	
   IIC_Stop();
}


/**
  * @brief  OLED图片填充
  * @param  fill_Data 要写入的数据
  * @retval 无
  */
void fill_picture(uint8_t fill_Data)
{
	uint8_t m, n;
	for(m = 0; m < 8; m++)
	{
		Write_IIC_Command(0xB0 + m);		//page0-page1
		Write_IIC_Command(0x02);		    //low column start address  低列起始地址
		Write_IIC_Command(0x10);		    //high column start address 高列起始地址

		for(n = 0; n < 128; n++)
        {
            Write_IIC_Data(fill_Data);
        }
	}
}


/**
  * @brief  OLED设置光标位置
  * @param  Y 以左上角为原点，向下方向的坐标，范围：0~7
  * @param  X 以左上角为原点，向右方向的坐标，范围：0~127
  * @retval 无
  */
void OLED_Set_Pos(uint8_t X, uint8_t Y) 
{ 
	Write_IIC_Command(0xB0 + Y);					            //设置Y位置
	Write_IIC_Command(0x10 | (((X + 2) & 0xF0) >> 4));	        //设置X位置高4位
	Write_IIC_Command(((X + 2) & 0x0F)); 			            //设置X位置低4位
} 


/**
  * @brief  OLED清屏
  * @param  无
  * @retval 无
  */
void OLED_Clear(void)  
{  
	uint8_t i, j;		    
	for(i = 0; i < 8; i++)  
	{  
		Write_IIC_Command(0xB0 + i);  //设置页地址（0~7）
		Write_IIC_Command(0x02);      //设置显示位置—列低地址
		Write_IIC_Command(0x10);      //设置显示位置—列高地址   
		for(j = 0; j < 128; j++)    
            Write_IIC_Data(0x00); 
	}                                       //更新显示
}


/**
  * @brief  开启OLED显示
  * @param  无
  * @retval 无
  */
void OLED_Display_On(void)
{
	Write_IIC_Command(0X8D);  //设置DCDC命令
	Write_IIC_Command(0X14);  //DCDC ON
	Write_IIC_Command(0XAF);  //DISPLAY ON
}


/**
  * @brief  关闭OLED显示
  * @param  无
  * @retval 无
  */   
void OLED_Display_Off(void)
{
	Write_IIC_Command(0X8D);  //SET DCDC命令
	Write_IIC_Command(0X10);  //DCDC OFF
	Write_IIC_Command(0XAE);  //DISPLAY OFF
}	


void OLED_On(void)  
{  
	uint8_t i, n;		    
	for(i = 0; i < 8; i++)  
	{  
		Write_IIC_Command(0xb0 + i);    //设置页地址（0~7）
		Write_IIC_Command(0x02);      //设置显示位置—列低地址
		Write_IIC_Command(0x10);      //设置显示位置—列高地址   
		for(n = 0; n < 128; n++)
            Write_IIC_Data(1); 
	} //更新显示
}


/**
  * @brief  在指定位置显示一个字符,包括部分字符
  * @param  X 行位置，范围：0~127
  * @param  Y 列位置，范围：0~63
  * @param  Char 要显示的一个字符，范围：ASCII可见字符
  * @param  Char_Size   选择字体 16/12 
  * @retval 无
  */
void OLED_ShowChar(uint8_t X, uint8_t Y, uint8_t Char, uint8_t Char_Size)
{      	
	uint8_t c = 0, i = 0;	

	c = Char - ' ';                     //得到偏移后的值	

	if(X > Max_Column - 1)
    {   
        X = 0;
        Y = Y + 2;
    }
	if(Char_Size == 16)
    {
        OLED_Set_Pos(X, Y);	
        for(i = 0; i < 8; i++)
            Write_IIC_Data(F8X16[c * 16 + i]);
            OLED_Set_Pos(X, Y + 1);
        for(i = 0; i < 8; i++)
            Write_IIC_Data(F8X16[c * 16 + i + 8]);
    }
    else 
    {	
        OLED_Set_Pos(X, Y);
        for(i = 0; i < 6; i++)
            Write_IIC_Data(F6x8[c][i]);
    }
}


/**
  * @brief  OLED次方函数
  * @param  X 行位置，范围：0~127
  * @param  Y 列位置，范围：0~63
  * @retval 返回值等于X的Y次方
  */
uint32_t OLED_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while (Y--)
	{
		Result *= X;
	}
	return Result;
}		


/**
  * @brief  显示数字
  * @param  X 行位置，范围：0~127
  * @param  Y 列位置，范围：0~63
  * @param  Length  数字的位数
  * @param  Number 要显示的数字，数值(0 ~ 4294967295);
  * @param  Char_Size   选择字体 16/12 
  * @retval 无
  */		  
void OLED_ShowNum(uint8_t X, uint8_t Y, uint32_t Number, uint8_t Length, uint8_t size)
{         	
	uint8_t t, temp;
	uint8_t enshow=0;	

	for(t = 0; t < Length; t++)
	{
		temp = (Number / OLED_Pow(10, Length - t - 1)) % 10;
		if(enshow == 0 && t < (Length - 1))
		{
			if(temp == 0)
			{
				OLED_ShowChar(X + (size / 2) * t, Y, ' ', size);
				continue;
			}
            else 
                enshow=1; 
		}
	 	OLED_ShowChar(X + (size / 2) * t, Y, temp + '0', size); 
	}
} 


/**
  * @brief  OLED显示字符串
  * @param  X 行位置，范围：0~127
  * @param  Y 列位置，范围：0~63
  * @param  String 要显示的字符串，范围：ASCII可见字符
  * @param  Char_Size   选择字体 16/12 
  * @retval 无
  */
void OLED_ShowString(uint8_t X, uint8_t Y, uint8_t *String, uint8_t Char_Size)
{
	uint8_t j = 0;
	while (String[j] != '\0')
	{		
        OLED_ShowChar(X, Y, String[j], Char_Size);
		X += 8;
		if(X > 120)
        {
            X = 0;
            Y += 2;
        }
		    j++;
	}
}


/**
  * @brief  OLED显示汉字
  * @param  X 行位置，范围：0~127
  * @param  Y 列位置，范围：0~63
  * @param  adder 汉字库内对应汉字的地址
  * @retval 无
  */
void OLED_ShowChinese(uint8_t X, uint8_t Y, uint8_t add)
{      			    
	uint8_t t, adder = 0;

	OLED_Set_Pos(X, Y);	
    for(t = 0; t < 16; t++)
	{
        Write_IIC_Data(Hzk[2 * add][t]);
        adder += 1;
    }	
		OLED_Set_Pos(X, Y+1);	
    for(t = 0; t < 16; t++)
	{	
        Write_IIC_Data(Hzk[2 * add + 1][t]);
        adder += 1;
    }					
}


/**
  * @brief  OLED显示图片，显示BMP图片128×64
  * @param  X0 行起始位置，范围：0~127
  * @param  X1 行结束位置，范围：0~127
  * @param  Y0 列起始位置，范围：0~127
  * @param  Y1 列结束位置，范围：0~127
  * @param  BMP 要显示的图片数组，范围：图库取模
  * @retval 无
  */
void OLED_DrawBMP(uint8_t X0, uint8_t X1, uint8_t Y0, uint8_t Y1, uint8_t BMP[])
{ 	
    uint32_t j = 0;
    uint8_t X, Y;
  
  if(Y1 % 8 == 0)
        Y = Y1 / 8;      
  else 
        Y = Y1 / 8 + 1;

	for(Y = Y0; Y < Y1; Y++)
	{
		OLED_Set_Pos(X0, Y);
        for(X = X0; X < X1; X++)
        {      
            Write_IIC_Data(BMP[j++]);	    	
        }
	}
}


/**
  * @brief  OLED初始化
  * @param  无
  * @retval 无
  */				    
void OLED_Init(void)
{ 	
    Delay_ms(100);			    //上电延时

    OLED_I2C_Init();			//端口初始化

	Write_IIC_Command(0xAE);	//关闭显示
	Write_IIC_Command(0x02);    //设置低列地址
	Write_IIC_Command(0x10);    //设置高列地址
	
    Write_IIC_Command(0xD8);    //设置区域颜色模式关闭
	Write_IIC_Command(0x05);

	Write_IIC_Command(0xD5);	//设置显示时钟分频比/振荡器频率
	Write_IIC_Command(0x80);
	
    Write_IIC_Command(0xA8);	//设置多路复用率
	Write_IIC_Command(0x3F);

    Write_IIC_Command(0xD3);	//设置显示偏移
	Write_IIC_Command(0x00);

    Write_IIC_Command(0x40);	//设置显示开始行
    Write_IIC_Command(0xB0);    //设置页面地址

    Write_IIC_Command(0xA1);	//设置左右方向，0xA1正常 0xA0左右反置

	Write_IIC_Command(0xC8);	//设置上下方向，0xC8正常 0xC0上下反置

	Write_IIC_Command(0xDA);	//设置COM引脚硬件配置
	Write_IIC_Command(0x12);

    Write_IIC_Command(0x81);	//设置对比度控制
	Write_IIC_Command(0xFF);    //128  

    Write_IIC_Command(0xD9);	//设置预充电周期
	Write_IIC_Command(0xF1);
	
	Write_IIC_Command(0xDB);	//设置VCOMH取消选择级别
	Write_IIC_Command(0x30);

    Write_IIC_Command(0xA6);	//设置正常/倒转显示
	
	Write_IIC_Command(0x8D);	//设置充电泵
	Write_IIC_Command(0x14);
	
	Write_IIC_Command(0xAF);	//开启显示

    OLED_Clear();				//OLED清屏
}  

