#ifndef __ENCODER_H__
#define __ENCODER_H__

#include "stm32f10x.h" 

void Encoder_Init(void);
void CountSensor_Init(void);
uint8_t CountSensor_Get(void);
uint8_t cnt_clear(void);
uint16_t Encoder_Get(void);
uint8_t Key_GetNum(void);


#endif


