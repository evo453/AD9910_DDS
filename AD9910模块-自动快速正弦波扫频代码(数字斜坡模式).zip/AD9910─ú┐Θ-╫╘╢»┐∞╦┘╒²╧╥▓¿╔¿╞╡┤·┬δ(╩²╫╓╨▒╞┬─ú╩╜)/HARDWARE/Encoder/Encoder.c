#include "stm32f10x.h"                  // Device header
#include "Encoder.h"
#include "MY_Delay.h"

static uint8_t FSM_Flag = 0;			//定义变量


void Encoder_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;								//定义GPIO口结构体
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;					//定义TIM4的结构体
	TIM_ICInitTypeDef TIM_ICInitStructure;								//定义输入捕获的结构体
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);										//TIM4是APB1总线的外设
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB,ENABLE);				//打开GPIO的时钟
	
	//================旋转编码器IO口初始化===================//
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;						//IPU上拉输入模式
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7; 				//选择6.7号引脚
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;					//速度选择50MHz
	GPIO_Init(GPIOB,&GPIO_InitStructure);								//GPIO初始化.使用PB总线
	//=======================================================//	
	
	//===================按键IO口初始化=====================//
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;						//Mode_IPU.上拉输入
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15;	
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;					//该参数为GPIO的输出速度，输入状态下无影响
	GPIO_Init(GPIOB,&GPIO_InitStructure);								//GPIO初始化.使用PE总线
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_11;	
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	//======================================================//
	
	//==================TIM4定时器初始化=====================//
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;			//指定时钟分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;	    //计数器模式->向上计数\向下计数\中央对齐
	TIM_TimeBaseInitStructure.TIM_Period = 65535-1;						//ARR 自动重装器的值（0-65535）
	TIM_TimeBaseInitStructure.TIM_Prescaler = 1-1;						//PSC 预分频器的值（0-65535）
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;				//（高级定时器专有）重复计数器的值
	// 定时频率 = 72M /（PSC+1）/（ARR+1）
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStructure);					//初始化时基单元
	//=======================================================//
	
	//================TIM4通道输入捕获初始化===================//
	TIM_ICStructInit(&TIM_ICInitStructure);								//设置默认初始值，防止未配置的结构体单元因不确定值出问题
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;					//指定IC输入捕获的通道
	TIM_ICInitStructure.TIM_ICFilter = 0xF;								//选择输入捕获的滤波器
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;			//极性.编码器高低电平极性不反转
	TIM_ICInit(TIM4,&TIM_ICInitStructure);								//输入捕获通道初始化
	
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;					//指定IC输入捕获的通道
	TIM_ICInitStructure.TIM_ICFilter = 0xF;								//选择输入捕获的滤波器
	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;			//极性.编码器高低电平极性不反转
	TIM_ICInit(TIM4,&TIM_ICInitStructure);								//输入捕获通道初始化
	//=========================================================//
	
	TIM_EncoderInterfaceConfig(TIM4, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);			//编码器接口配置,任一极性设置反转，记增减的方向翻转
	
	TIM_Cmd(TIM4,ENABLE);												//TIM4定时器使能
}



 void CountSensor_Init(void)						//外部中断通道选择初始化
{
	GPIO_InitTypeDef GPIO_InitStucture;
	EXTI_InitTypeDef EXTI_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);					//打开GPIOB的时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);						//打开AFIO的时钟
	//RCC管的内核外的外设
	//EXTI（外部中断）,NVIC（中断管理）默认开启时钟，无需设置

	GPIO_InitStucture.GPIO_Mode = GPIO_Mode_IPU;							//上拉输入
	GPIO_InitStucture.GPIO_Pin = GPIO_Pin_5;
	GPIO_InitStucture.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB,&GPIO_InitStucture);
	
	GPIO_EXTILineConfig(GPIO_PortSourceGPIOB,GPIO_PinSource5); 			//AFIO：1.选择某个GPIO外设作为外部中断源 2.指定要配置的外设中断线


	EXTI_InitStructure.EXTI_Line = EXTI_Line5;							//指定要配置的中断线
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;							//指定选择的中断线的新状态->开启/关闭
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;					//指定外部中断线的模式->中断/(事件)模式
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;				//指定触发信号的有效边沿->上升/下降/上升下降都触发
	EXTI_Init(&EXTI_InitStructure);										//EXTI初始化
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);  				//配置优先级分组:抢占(先占)优先级和响应(从占)优先级
	
	NVIC_InitStructure.NVIC_IRQChannel = EXTI9_5_IRQn;				//指定中断通道来开启或关闭.IRQn_Type选择的通道根据芯片型号容量选择
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;						//指定中断通道使能还是失能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;			//指定所选中断通道的抢占优先级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;					//指定所选中断通道的响应优先级
	NVIC_Init(&NVIC_InitStructure);										//NVIC初始化
} 

uint8_t CountSensor_Get(void)
{
	if(FSM_Flag == 5)
		FSM_Flag = 0;
	return FSM_Flag;						//返回变量
}

void EXTI9_5_IRQHandler(void)
{
	if(EXTI_GetITStatus(EXTI_Line5) == SET)			//查看中断标志位，返回值为SET/RESET
	{
		FSM_Flag++;									//中断进行一次加1
		EXTI_ClearITPendingBit(EXTI_Line5);			//清除中断标志位
	}
}


uint8_t cnt_clear(void)
{
	uint8_t clear = 0;												//按键键码默认为0
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_12) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{											
		clear = 1;													//将键码返回1	
	}
	return clear;
}

uint8_t Key_GetNum(void)
{
	uint8_t KeyNum = 0;												//按键键码默认为0
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{
//		Delay_ms(20);												//按键消抖
//		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13) == 0);		//不松手一直卡死在读取按键状态下
		Delay_ms(20);												
		KeyNum = 1;													//将键码返回1	
	}
	\
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{
//		Delay_ms(20);												//按键消抖
//		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14) == 0);		//不松手一直卡死在读取按键状态下
		Delay_ms(20);												
		KeyNum = 2;													//将键码返回2	
	}
	
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{
//		Delay_ms(20);												//按键消抖
//		while(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_15) == 0);		//不松手一直卡死在读取按键状态下
		Delay_ms(20);												
		KeyNum = 3;													//将键码返回3	
	}
	
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{
//		Delay_ms(20);												//按键消抖
//		while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8) == 0);		//不松手一直卡死在读取按键状态下
		Delay_ms(20);												
		KeyNum = 4;													//将键码返回3	
	}
	
	if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11) == 0)				//使用函数读取是否有按键按下->按键按下接地，读取为低电平
	{
//		Delay_ms(20);												//按键消抖
//		while(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_11) == 0);		//不松手一直卡死在读取按键状态下
		Delay_ms(20);												
		KeyNum = 5;													//将键码返回3	
	}
	
	return KeyNum;
}


uint16_t Encoder_Get(void)
{
	uint16_t Temp;
	Temp = TIM_GetCounter(TIM4) / 4;
	return Temp;													//返回CNT计数的值
}

