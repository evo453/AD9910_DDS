#include "32_configuration.h"
#include <stdbool.h>

static uint16_t Freq_Buff[200];				//90M - 110M
const  uint16_t Amp_Buff_90[10] = {220, 545, 805, 1115, 1400, 1700, 1980, 2280, 2585, 2860};		//90M-10mVpp - 100mVpp
uint16_t DRG_Buff[] = {8000, 4000, 2667, 2000, 1600};			//扫频数组

static uint32_t Freq;	

volatile struct display{			//显示频率
	uint8_t integer;
	uint8_t decimals;
} value;


/**
   *  @brief	频率数组初始化赋值
   *  @param	无
   *  @retval	无
   */
void Freq_Array_Init(void)
{
	uint16_t add = 0, values = 900;					//频率设置数组

	for(add = 0; add <= 200; add++)
	{
		if(values <= 1100)
			Freq_Buff[add] = values++;
	}
}


/**
   *  @brief	频率设置
   *  @param	*adder 指向频率数组元素的地址
   *  @retval	无
   */
void Set_Freq(uint8_t *adder)
{
	if(*adder <= 200)							
	{
		Freq = Freq_Buff[*adder] * 100000;				// 90_000_000 = 900 * 100000;
		AD9910_FreWrite(Freq);
	}
}


/**
   *  @brief	幅度设置
   *  @param	*adder 指向幅度数组元素的地址
   *  @retval	无
   */	
void Set_Amp(uint8_t *adder)
{
	if((*adder <= 9))
	{
		AD9910_AmpWrite(Amp_Buff_90[*adder]);
	}
}


/**
   *  @brief	自动扫频&设置扫描时间
   *  @param	add 扫频时间设置参数
   *  @retval	无
   */
void DRG_FreqPara_AutoSet(uint8_t *add)
{
	AD9910_DRG_FreInit_AutoSet(ENABLE);					//使能自动扫描

//	AD9910_DRG_FrePara_Set(90000000, 110000000, 80, 80, 1000, 1000);		//	uint32_t POSRATE, uint32_t NEGRATE				UPSTEP, uint32_t NEGSTEP
	AD9910_DRG_FrePara_Set(90000000, 110000000, DRG_Buff[*add], DRG_Buff[*add], 50000, 50000);
}


/**
   *  @brief	手动扫频&设置上下限频率
   *  @param	cases 切换手动扫频模式模式
   *  @retval	无
   */
void Select_Mode(uint8_t cases)				//选择上扫频或下扫频的回调函数
{
		switch(cases)
		{
			case 1: AD9910_DRG_FrePara_Set(90000000, Freq, 2667, 0, 50000, 0);		//上扫频
					DRCTL = 1;
					break;
			
			case 2:	AD9910_DRG_FrePara_Set(Freq, 110000000, 0, 2667, 0, 50000);		//下扫频
					DRCTL = 0;
					break;
		}
}

void DRG_FreqManual_BoundSet(uint8_t cases, uint8_t *add, void (*GetNextValue)(uint8_t))			//设置上下限扫频函数
{
	AD9910_DRG_FreInit_AutoSet(DISABLE);			//失能自动扫描
	
	if(*add <= 200)
	{
		Freq = Freq_Buff[*add] * 100000;				//设置上下限
	}
	GetNextValue(cases);											//调用扫频回调函数
}
//========================================//


/**
   *	@brief	固定79MHz
   *	@param	无
   *	@retval 无
   */
void select(void)
{
	Freq = 79000000;
	AD9910_FreWrite(Freq);
}

/**
   *  @brief	频率显示
   *  @param	无
   *  @retval	无
   */
void Freq_display(void)
{
	value.integer = Freq / 1000000;
	value.decimals  = (Freq - ((Freq / 1000000) * 1000000)) / 100000;
	
	OLED_ShowNum(40, 0, value.integer, 3, 12);
	OLED_ShowNum(72, 0, value.decimals, 1, 12);
}


/**
   *	@brief	模式显示
   *	@param	无
   *	@retval 无
   */
void Mode_display(void)
{
	uint8_t flag;
	
	flag = CountSensor_Get();
	switch(flag)
	{
		case 0: OLED_ShowString(48, 2, "Select  ", 12);break;
		case 1: OLED_ShowString(48, 2, "Set_Freq", 12);break;
		case 2: OLED_ShowString(48, 2, "Set_Amp ", 12);break;
		case 3: OLED_ShowString(48, 2, "DRG_auto", 12);break;
		case 4: OLED_ShowString(48, 2, "DRG_hand", 12);break;
	}
}


