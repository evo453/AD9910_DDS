#ifndef __CTRL_H__
#define __CTRL_H__

#include "stm32f10x.h"                  // Device header

void Freq_Array_Init(void);

void Set_Freq(uint8_t *adder);
void Set_Amp(uint8_t *adder);
void DRG_FreqPara_AutoSet(uint8_t *add);
void Select_Mode(uint8_t cases);
void DRG_FreqManual_BoundSet(uint8_t cases, uint8_t *add, void (*GetNextValue)(uint8_t));
void select(void);

void Freq_display(void);
void Mode_display(void);


#endif


