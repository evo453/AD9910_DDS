#ifndef __AD9910_H__
#define __AD9910_H__

#include "stm32f10x.h"


#define uchar unsigned char
#define uint  unsigned int	
#define ulong  unsigned long int

#define AD9910_PWR			PBout(11)
#define AD9910_SDIO			PAout(2)
#define DRHOLD				PAout(1)
#define DROVER				PAout(3)
#define UP_DAT				PAout(5)
#define PROFILE1			PBout(1)
#define MAS_REST			PBout(10)
#define SCLK				PAout(0)
#define DRCTL				PAout(4)
#define OSK					PAout(6)
#define PROFILE0			PAout(7)
#define PROFILE2			PBout(0)
#define CS					PCout(15)


////#define AD9910_CSN_Set CS = 1
////#define AD9910_CSN_Clr CS = 0

////#define AD9910_IUP_Set UP_DAT = 1     
////#define AD9910_IUP_Clr UP_DAT = 0

typedef enum {
	TRIG_WAVE = 0,
	SQUARE_WAVE,
	SINC_WAVE,
} AD9910_WAVE_ENUM;

void AD9110_IOInit(void);				//IO口初始化
void Init_AD9910(void);					//AD9910初始化
void AD9910_FreWrite(ulong Freq);		//写频率
void AD9910_AmpWrite(uint16_t Amp);		//写幅度

  
void AD9910_RAM_WAVE_Set(AD9910_WAVE_ENUM wave);			//控制输出波形


void AD9910_DRG_FreInit_AutoSet(FunctionalState autoSweepEn);		//控制是否自动扫频，否则切换到手动扫频
void AD9910_DRG_FrePara_Set(u32 lowFre, u32 upFre, u32 posStep, u32 negStep, u32 posRate, u32 negRate);		//进行上下限循环扫频
//设定扫频参数：（频率上限， 频率下限， 上扫频步进时间， 下扫频步进时间， 上扫频频点停留时间，下扫频频点停留时间）


#endif


