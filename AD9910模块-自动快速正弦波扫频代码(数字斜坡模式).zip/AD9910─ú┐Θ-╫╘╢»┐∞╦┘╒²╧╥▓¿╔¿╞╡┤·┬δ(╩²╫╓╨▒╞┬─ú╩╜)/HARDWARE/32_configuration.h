#ifndef __32_CONFIGURATION_H__
#define __32_CONFIGURATION_H__

#include "stm32f10x.h"                  // Device header
#include "sys.h"
#include "usart.h"
#include "MY_Delay.h"

#include "AD9910.h"
#include "Encoder.h."
#include "ctrl.h"
#include "Init.h"
#include "OLED_High_inch.h"				//1.3��OLED
//#include "OLED.h"						//0.96��OLED




#endif
