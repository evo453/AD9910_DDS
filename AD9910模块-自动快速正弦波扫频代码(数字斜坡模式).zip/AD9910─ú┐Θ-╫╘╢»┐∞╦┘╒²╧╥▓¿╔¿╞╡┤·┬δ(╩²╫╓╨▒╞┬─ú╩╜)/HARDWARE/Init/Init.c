#include "32_configuration.h"
#include "Init.h"


/**
   *  @brief	配置初始化
   *  @param	无
   *  @retval	无
   */
void All_Init(void)
{
	//=======所有外设和系统配置初始化========//
	OLED_Init();
//	USARTx_Init();
	Encoder_Init();
	CountSensor_Init();
	Init_AD9910();					//AD9910控制脚及寄存器初始化
	//=====================================//
	
	
	//======控制模块频率控制数组初始化======//
	Freq_Array_Init();
	//=====================================//
}

/**
   *  @brief	固定函数调用
   *  @param	无
   *  @retval	无
   */
void Basic_Set(void)
{
	OLED_ShowString(0, 0, "Freq:", 12);			//16号字体大小一个字 X 轴占 8 字节， Y 轴占 2 字节， 即X的位置 = 128/8， Y = 8/2,
	OLED_ShowString(64, 0, ".", 12);			//12号 X 轴一样
	OLED_ShowString(80, 0, "MHz", 12); 
	
	OLED_ShowString(0, 2, "Mode:", 12); 
	
	OLED_ShowString(0, 4, "CNT:", 12); 
	OLED_ShowString(64, 4,"State:", 12); 
	OLED_ShowString(0, 6, "Key:", 12); 
}

