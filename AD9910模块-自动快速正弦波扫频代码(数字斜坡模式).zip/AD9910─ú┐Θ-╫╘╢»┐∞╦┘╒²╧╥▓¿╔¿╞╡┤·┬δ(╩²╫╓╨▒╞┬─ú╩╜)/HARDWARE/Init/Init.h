#ifndef __INIT_H__
#define __INIT_H__

#include "32_configuration.h"


void All_Init(void);
void Basic_Set(void);



#endif


