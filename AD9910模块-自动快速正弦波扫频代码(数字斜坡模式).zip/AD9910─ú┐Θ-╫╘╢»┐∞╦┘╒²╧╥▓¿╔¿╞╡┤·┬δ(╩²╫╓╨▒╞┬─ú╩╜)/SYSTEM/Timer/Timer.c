#include "stm32f10x.h"                  // Device header

void Timer_Init(void)
{
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4,ENABLE);					//TIM4是APB1总线的外设
	
	TIM_InternalClockConfig(TIM4);										//选择TIM4时基单元由内部时钟驱动，如果不写，默认使用内部时钟
	
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
	TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;			//指定时钟分频
	TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;	    //计数器模式->向上计数\向下计数\中央对齐
	TIM_TimeBaseInitStructure.TIM_Period = 1200-1;						//ARR自动重装器的值（0-656535）
	TIM_TimeBaseInitStructure.TIM_Prescaler = 60000-1;					//PSC预分频器的值（0-65535）
	TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;				//（高级定时器专有）重复计数器的值
	// 定时频率 = 72M /（PSC+1）/（ARR+1）
	
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseInitStructure);					//TIM初始化
	TIM_ClearFlag(TIM4,TIM_FLAG_Update);								//手动将更新中断标志位清除，避免刚初始化完就进入中断
	
	TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);							//使能中断->选择定时器，更新中断,状态
	//到此开启了更新中断到NVIC的通道

	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);						//中断优先级分组	

	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;						//中断通道
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;						//中断状态
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 4;			//抢占优先级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;					//响应优先级
	
	NVIC_Init(&NVIC_InitStructure);										//NVIC初始化
	
	TIM_Cmd(TIM4,ENABLE);												//定时器控制
}

/*//中断函数模版
void TIM4_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2,TIM_IT_Update) == SET)					//->查看中断口.更新中断标志位
	{
		Num++;
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
	}
	
}
*/

