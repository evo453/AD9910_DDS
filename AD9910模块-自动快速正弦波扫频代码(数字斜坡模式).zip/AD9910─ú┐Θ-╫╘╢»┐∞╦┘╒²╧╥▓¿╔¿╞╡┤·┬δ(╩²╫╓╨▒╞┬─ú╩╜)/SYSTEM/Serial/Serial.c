#include "stm32f10x.h"                  // Device header
#include <stdio.h>
#include <stdarg.h>
#include "Serial.h"

uint8_t Serial_RxData;
uint8_t Serial_RxFlag;

void Serial_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);		//使能USART1，GPIOA时钟
		
	USART_DeInit(USART1); 																 //复位串口1
	
	//USART1_TX   PA.9
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; 											//PA.9
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;										//复用推挽输出
	GPIO_Init(GPIOA, &GPIO_InitStructure); 												//初始化PA9
   
	//USART1_RX	  PA.10
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure);  											//初始化PA10
  
	//USART 初始化设置
	USART_InitStructure.USART_BaudRate = 9600;											//设置波特率，一般设置为9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;							//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;								//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;									//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;		//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;						//收发模式
	
	USART_Init(USART1, &USART_InitStructure); 											//初始化串口
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);									//开启RXNE标志位到NVIC的输出
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);									//配置优先级分组:抢占(先占)优先级和响应(从占)优先级
	

	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;								//中断通道
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;									//指定中断通道使能还是失能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;						//指定所选中断通道的抢占优先级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;								//指定所选中断通道的响应优先级
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART1,ENABLE);											//USART使能
}




void Serial_SendByte(uint8_t Byte)									//发送一个字节
{
	USART_SendData(USART1, Byte);
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	//获取标志位 ->	TXE发送数据寄存器空标志位,等待发送完成
}

void Serial_SendArray(uint8_t *Array,uint16_t Length)				//发送一个数组
{
	uint16_t i;
	for(i = 0 ;i < Length ; i++)
	{
		Serial_SendByte(Array[i]);
	}
}

void Serial_SendString(uint8_t *String)
{
	uint8_t i;
	for(i = 0; String[i] != '\0'; i++)
	{
		Serial_SendByte(String[i]);
	}
}

uint32_t Serial_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while(Y--)
	{
		Result *= X;
	}
	return Result;
}

void Serial_SendNumber(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for(i = 0; i < Length ;i++)
	{
		Serial_SendByte(Number / Serial_Pow(10, Length - 1 - i) % 10 + '0');
	}
}




/*中断接收*/
uint8_t Serial_GetRxFlag(void)								//读取后自动清除标志位
{
	if(Serial_RxFlag == 1)
	{
		Serial_RxFlag =0;
		return 1;
	}
	return 0;
}

uint8_t Serial_GetRxData(void)								
{
	return Serial_RxData;
}


void USART1_IRQHandler(void)								//中断接收
{
		if(USART_GetFlagStatus(USART1, USART_IT_RXNE) == SET)		//接受标志位判断
		{
			Serial_RxData = USART_ReceiveData(USART1);								//读取数据
			Serial_RxFlag = 1;														//手动置1
			USART_ClearITPendingBit(USART1, USART_IT_RXNE);							//清除标志位
		}
}
/*******/

