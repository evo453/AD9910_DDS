#include "usart.h"
#include "sys.h"
#include "32_configuration.h"


uint8_t USART_RxFlag;
uint8_t USART_RxData;


/**
   *  @brief	初始化串口
   *  @param	无
   *  @retval	无
   */
void USARTx_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
//#ifdef EN_USART1_RX	//如果使能了接收中断
//	
//	USART1 -> CR1 |= 1 << 8;	//PE中断使能
//	USART1 -> CR1 |= 1 << 5;	//接收缓冲区非空中断使能
//	
//	MY_NVIC_Init(3, 3, USART1_IRQn, NVIC_PriorityGroup_2);								//中断分组2，最低优先级
//	
//#endif

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);		//使能USART1，GPIOA时钟
		
	USART_DeInit(USART1); 																 //复位串口1
	
	//USART1_TX   PA.9
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9; 											//PA.9
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;										//复用推挽输出
	GPIO_Init(GPIOA, &GPIO_InitStructure); 												//初始化PA9
   
	//USART1_RX	  PA.10
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;								//浮空输入
	GPIO_Init(GPIOA, &GPIO_InitStructure);  											//初始化PA10
  
	//USART 初始化设置
	USART_InitStructure.USART_BaudRate = 9600;											//设置波特率，一般设置为9600;
	USART_InitStructure.USART_WordLength = USART_WordLength_8b;							//字长为8位数据格式
	USART_InitStructure.USART_StopBits = USART_StopBits_1;								//一个停止位
	USART_InitStructure.USART_Parity = USART_Parity_No;									//无奇偶校验位
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;		//无硬件数据流控制
	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;						//收发模式
	
	USART_Init(USART1, &USART_InitStructure); 											//初始化串口
	USART_ITConfig(USART1, USART_IT_RXNE, ENABLE);										//开启中断，RXNE标志位到NVIC的输出
	
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);									//配置优先级分组:抢占(先占)优先级和响应(从占)优先级
	
	NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;								//中断通道
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;									//指定中断通道使能还是失能
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;						//指定所选中断通道的抢占优先级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;								//指定所选中断通道的响应优先级
	NVIC_Init(&NVIC_InitStructure);
	
	USART_Cmd(USART1, ENABLE);                    										//使能串口 

}


//=========================================
//**************数据发送*******************//

/**
   *  @brief	发送一个字节
   *  @param	Byte 要发送的字节
   *  @retval	无
   */
void Serial_SendByte(uint8_t Byte)
{
	USART_SendData(USART1, Byte);
	while(USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET);	//获取标志位 ->	TXE发送数据寄存器空标志位,等待发送完成
}


/**
   *  @brief	发送一个数组
   *  @param	*Array 要发送的数组
   *  @param	Length 数组的长度
   *  @retval	无
   */
void Serial_SendArray(uint8_t *Array,uint16_t Length)
{
	uint16_t i;
	for(i = 0 ;i < Length ; i++)
	{
		Serial_SendByte(Array[i]);
	}
}


/**
   *  @brief	发送字符串
   *  @param	*String 要发送的字符串
   *  @retval	无
   */
void Serial_SendString(uint8_t *String)
{
	uint8_t i;
	for(i = 0; String[i] != '\0'; i++)
	{
		Serial_SendByte(String[i]);
	}
}


uint32_t Serial_Pow(uint32_t X, uint32_t Y)
{
	uint32_t Result = 1;
	while(Y--)
	{
		Result *= X;
	}
	return Result;
}


/**
   *  @brief	发送数字
   *  @param	Number 要发送的数字
   *  @param	Length 数字长度
   *  @retval	无
   */
void Serial_SendNumber(uint32_t Number, uint8_t Length)
{
	uint8_t i;
	for(i = 0; i < Length ;i++)
	{
		Serial_SendByte(Number / Serial_Pow(10, Length - 1 - i) % 10 + '0');
	}
}

//*****************************************//
//=========================================






/**
   *  @brief	接收中断标志位
   *  @param	无
   *  @retval	无
   */
uint8_t Serial_GetRxFlag(void)			//读取后自动清除标志位
{
	if(USART_RxFlag == 1)
	{
		USART_RxFlag =0;
		return 1;
	}
	return 0;
}


/**
   *  @brief	接收数据
   *  @param	无
   *  @retval	无
   */
uint8_t Serial_GetRxData(void)						
{
	return USART_RxData;
}


/**
   *  @brief	系统接收中断函数
   *  @param	无
   *  @retval	无
   */
void USART1_IRQHandler(void)								//中断接收
{
	if(USART_GetFlagStatus(USART1, USART_IT_RXNE) == SET)		//接受标志位判断
	{
		USART_RxData = USART_ReceiveData(USART1);								//读取数据
		USART_RxFlag = 1;																				//手动置1
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);					//清除标志位
	}
}

//*************************************//
//=======================================







































/**********************************************************
   加入以下代码，支持printf函数，而不需要选择use MicroLIB
**********************************************************/

#if 1

#pragma import(__use_no_semihosting)             
//标准库需要的支持函数                 
struct __FILE 
{ 
	int handle; 

}; 
/* FILE is typedef’ d in stdio.h. */ 
FILE __stdout;       
//定义_sys_exit()以避免使用半主机模式    
_sys_exit(int x) 
{ 
	x = x; 
} 
//重定义fputc函数 
int fputc(int ch, FILE *f)
{
	while((USART1->SR & 0x40) == 0);	//循环发送，直到发送完毕   
    USART1->DR = (uint8_t)ch;	//发送数据      
	return ch;
}
#endif
/**********************   end   **************************/




////=========================================================
// 
//#ifdef EN_USART1_RX   //如果使能了接收

////=========================================================

////串口1中断服务程序
////注意,读取USARTx->SR能避免莫名其妙的错误 

//uint8_t USART_RX_BUF[USART_REC_LEN];	//接收缓冲,最大USART_REC_LEN个字节

////接收状态
////bit15：接收完成标志
////bit14：接收到0x0d
////bit13~0：接收到的有效字节数目，最大512字节

//uint16_t USART_RX_STA=0;	//接收状态标记	  

///**********************************************************
//* 函数功能 ---> 串口1接收中断服务程序
//* 入口参数 ---> bound：波特率	
//* 返回数值 ---> none
//* 功能说明 ---> none
//**********************************************************/
//void USART1_IRQHandler(void)
//{
//	uint8_t res;

//	if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)  //接收到数据，接收标志位判断
//	{
//		res = USART_ReceiveData(USART1);	//读取接收到的数据
//		
//		if((USART_RX_STA & 0x8000) == 0)//接收未完成
//		{
//			if(USART_RX_STA & 0x4000)//接收到了0x0d
//			{
//				/***********************************************
//                                  修改内容如下
//                    当用户数据当中有0x0d的时候修正的错误的判断
//				***********************************************/
//				
//				if(res != 0x0a)
//				{
//					USART_RX_BUF[USART_RX_STA & 0x3fff] = 0x0d;	//补上丢失的0x0d数据
//					USART_RX_STA++;
//					USART_RX_BUF[USART_RX_STA & 0x3fff] = res;	//继续接收数据
//					USART_RX_STA++;
//					USART_RX_STA &= 0xbfff;						//清除0x0d标志
//				}
//				
//				/***********************************************
//                                      修改完成
//				***********************************************/
//				
//				else	USART_RX_STA |= 0x8000;	//接收完成了
//			}
//			else //还没收到0x0d
//			{	
//				if(res == 0x0d)	USART_RX_STA |= 0x4000;
//				else
//				{
//					USART_RX_BUF[USART_RX_STA & 0x3fff] = res;
//					USART_RX_STA++;
//					if(USART_RX_STA > (USART_REC_LEN - 1))	USART_RX_STA = 0;//接收数据错误,重新开始接收	  
//				}		 
//			}
//		}	//end 接收未完成   	
//			
////		USART_ClearITPendingBit(USART1, USART_IT_RXNE);							//清除标志位
//	}	//end 接收到数据
//}

////=========================================================

//#endif	//end使能接收

////=========================================================






