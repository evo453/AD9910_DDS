#include "32_configuration.h"
#include "bmp.h"



uint8_t Count;			//编码器计数变量
uint8_t *add;			//控制变量
uint8_t State_Flag = 0;	//状态标志位
uint8_t Event = 0;
uint8_t cnt, cnt_flag;
uint32_t freq;	



int main(void)
{
	All_Init();						//包含所有初始化

	Delay_ms(300);					//延时一会儿，等待上电稳定

	AD9910_FreWrite(79000000);		//上电初始化频率自79M开始
	AD9910_AmpWrite(16383);			//  0 - 16383
	
	Basic_Set();					//基础显示

	
	while(1)
	{		
		Count = Encoder_Get();				//编码器计数
		add = &Count;
		Event = Key_GetNum();
		
		if(cnt_clear() == 1) TIM4 -> CNT = 0;
		
		State_Flag = CountSensor_Get();
		
		switch(State_Flag)
		{
			case 0: break;
			
			case 1: Set_Freq(add);									//设置频率
					break;
			case 2:	Set_Amp(add);									//设置幅度
					break;	
			case 3:	DRG_FreqPara_AutoSet(add);						//90-110M自动扫频
					break;
			case 4:	DRG_FreqManual_BoundSet(Event, add, Select_Mode);	//手动扫频
					break;
		}

		
		Freq_display();
		Mode_display();
		
		OLED_ShowNum(32, 4, Count, 3, 12);
		OLED_ShowNum(108, 4, State_Flag, 3, 12);
		OLED_ShowNum(32, 6, Event, 3, 12);
	}
	
}


